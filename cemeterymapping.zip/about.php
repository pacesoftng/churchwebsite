
<style type="text/css">
    .row div {
        font-size: 13px;
        font-weight: bold;
        border-bottom: .5px solid #ddd;
        margin-bottom: 1px;
    }
</style>
<div class="row"> 
    <div class="col-lg-12">
        <div><img src="img/IMG_20180308_170337.jpg" title="img" style="width: 100px;height: 100px"> Rhea A. Gregorio - Project Manager </div>
        <div><img src="img/IMG_20180206_115840.jpg" title="img" style="width: 100px;height: 100px"> Ana Marie S. Mallen - Programmer</div>
        <div><img src="img/BeautyPlus_20170723213434_fast.jpg" title="img" style="width: 100px;height: 100px"> Rachel M, magtuba - Web Developer</div>
        <div><img src="img/IMG_20180311_204723.jpg" title="img" style="width: 100px;height: 100px"> Trisha Ann B. Gabales - System Analyst</div>
        <div><img src="img/IMG_20180311_204649_053 (1).jpg" title="img" style="width: 100px;height: 100px"> Jyan M. Francisco - Documenter</div> 
    </div>
        
</div>