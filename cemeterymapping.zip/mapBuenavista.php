<?php 

include "mapSectionABuenavistaFunc.php";
include "mapSectionBBuenavistaFunc.php";
?>
 
 

<style type="text/css">
 
 
	.style2{
    	width: 1100px;
    	height: 500px;
          background: url(img/bgbunavista.jpg);
      /*            -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover; 
        background-size: cover;*/
      
}
</style>
<div class="style2">
<div class="row">
<div class="col-lg-4">
	<div class="row">
		<p class="sections"></p> 
	</div>
</div>
<div class="col-lg-4 seperatorHeading"></div>
 <div class="col-lg-4">
	<div class="row">
		<p class="sections"></p>
	</div>
</div>
</div>

<div class="container " style="margin: 80px 0px 0px 0px">
<div class="row tooltip-demo">
	<div class="col-md-6 longonBorder" >
				 <!-- twelve row -->
			<div class="col-lg-12 row">
				<div class="col-md-2 longonBorder" style=" "></div> 
				<div class="col-md-1" style=" "><?php  sectionA_elevenrow_secondcolumn(); ?></div> 
				<div class="col-md-3" style=" "></div> 
				<div class="col-md-6" style=" "><?php  sectionA_elevenrow_firstcolumn(); ?></div> 
			</div>
				<!-- end -->
			 <!-- eleven row -->
			<div class="col-lg-12 row"> 
				<div class="col-md-1" style=" "></div> 
				<div class="col-md-1" style=" "><?php  sectionA_tenrow_secondcolumn(); ?></div> 
				<div class="col-md-3" style=" "></div> 
				<div class="col-md-7" style=" "><?php  sectionA_tenrow_firstcolumn(); ?></div>
			</div>
				<!-- end -->
			<!-- ten row -->
			<div class="col-lg-12 row">
				<div class="col-md-2" style=" "></div>  
				<div class="col-md-10" style=" "><?php  sectionA_ninerow_firstcolumn(); ?></div> 
			</div>
  				<!-- end -->

		  <!-- nine row -->
			<div class="col-lg-12 row">
				<div class="col-md-12 longonBorder" ><?php  sectionA_eightrow_firstcolumn(); ?></div>  
			</div>
			<!-- end -->
			<!-- <div class="col-md-12 thirdway longonBorder" style="height: 5px;  "> 
			</div>  -->
			<!-- eight row -->
			<div class="col-lg-12 row">	
				<div class="col-md-12 longonBorder" ><?php  sectionA_seventhrow_firstcolumn(); ?> </div> 
			</div>
			<!-- end -->
			<!-- <div class="col-md-12 thirdway longonBorder" style="height: 5px;  "> 
			</div> 
 -->
 		<!-- seven row -->
 			<div class="col-lg-12 row">
 				<div class="col-md-12 longonBorder" ><?php  sectionA_sixthrow_firstcolumn(); ?></div> 
 			</div>
 			 <!-- end -->

		<!-- 	<div class="col-md-12 thirdway longonBorder" style="height: 5px;  "> 
			</div>  -->
				
			<!-- six row -->
			<div class="col-lg-12 row">
				<div class="col-md-4 longonBorder" ><?php  sectionA_fifthrow_thirdcolumn(); ?></div> 
				<div class="col-md-2 longonBorder" style=" "></div>
				<div class="col-md-6 longonBorder" ><?php  sectionA_fifthrow_firstcolumn(); ?></div>
			</div>
				<!-- end  --> 

			<!-- fifth row -->
			
			<div class="col-lg-12 row">
				<div class="col-md-9 longonBorder" style="">
					<div style="margin: 0px 0px 0px 150px;width: 30px"><?php sectionA_forthrow_secondcolumn(); ?></div>
				</div> 
				<div class="col-md-3 longonBorder" ><?php  sectionA_forthrow_firstcolumn(); ?></div> 
			</div>
			<!-- end -->
			
			<!-- forth row -->

			<div class="col-lg-12 row">
				<div class="col-md-11 longonBorder" style=" "></div> 
				<div class="col-md-1 longonBorder" ><?php  sectionA_thirdrow_firstcolumn(); ?></div> 
			</div>
			 <!-- end -->
		<!-- 	<div class="col-md-12 thirdway longonBorder" style="height: 5px;  "> 
			</div>  -->

		<!-- 	<div class="col-md-6 thirdway longonBorder" style="height: 5px;  "> 
			</div> 
			<div class="col-md-6 thirdway longonBorder" style="height: 5px;  "> 
			</div>  -->


			<!-- third row -->
			<div class="col-lg-12 row">
				<div class="col-md-6 longonBorder" ><?php  sectionA_secondrow_thirdcolumn(); ?></div>  
				<div class="col-md-2 longonBorder" ><?php  sectionA_secondrow_secondcolumn(); ?></div> 
				<div class="col-md-4 longonBorder" ><?php  sectionA_secondrow_firstcolumn(); ?></div>
			</div>
			 <!-- end -->
			<!-- second row -->
			<div class="col-lg-12 row">  
				<div class="col-md-6 longonBorder"><?php  sectionA_firstrow_thirdcolumn(); ?></div>  
				<div class="col-md-2 longonBorder"><?php  sectionA_firstrow_secondcolumn(); ?></div> 
				<div class="col-md-4 longonBorder"><?php  sectionA_firstrow(); ?></div> 
			</div>
			<!-- end -->
			<!-- first row -->
			<div class="col-lg-12 row">
				<div class="col-md-12 thirdway longonBorder" style="height: 5px;  "> </div>
			</div>
			<!-- end -->
		 
			
	</div> 


	<div class="col-md-6">
		 <!-- twelve row -->
		<div class="col-lg-12 row">
			<div class="col-md-4 longonBorder " ><?php  sectionB_tenrow_firstcolumn(); ?></div>
			<div class="col-md-2 longonBorder" style="border: 2px solid #ddd"><?php  sectionB_tenrow_secondcolumn(); ?></div>
			<div class="col-md-6 longonBorder partition " ></div> 
		</div>
		  
		<!-- end -->
		 <!-- twelve row -->
		<div class="col-lg-12 row">
			<div class="col-md-4 longonBorder " ><?php  sectionB_tenrow_firstcolumn(); ?></div>
			<div class="col-md-2 longonBorder" style="border: 2px solid #ddd"><?php  sectionB_tenrow_secondcolumn(); ?></div>
			<div class="col-md-6 longonBorder " style="padding-bottom:  3px"><?php  sectionB_tenrow_thirdcolumn(); ?></div> 
		</div>
		  
		<!-- end -->
				<!-- eleven row -->
		<div class="col-lg-12 row">
			<div class="col-md-10 longonBorder " ><?php  sectionB_ninerow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" > </div>
			<div class="col-md-1 longonBorder " ><?php  sectionB_ninerow_secondcolumn(); ?></div> 
		</div>
		  
		<!-- end -->
			<!-- ten row -->
		<div class="col-lg-12 row">
			<div class="col-md-4 longonBorder " ><?php  sectionB_eightrow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-2 longonBorder " ><?php  sectionB_eightrow_secondcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-4 longonBorder " ><?php  sectionB_paaman_row1_firstcolumn(); ?></div> 
		</div>
		  
		<!-- end -->
		<!-- nine row -->
		<div class="col-lg-12 row"> 

			<div class="col-md-3 longonBorder partition" ></div> 
			<div class="col-md-1 longonBorder" ><?php  sectionB_sevenrow_firstcolumn(); ?></div> 
			<div class="col-md-1 longonBorder partition" ></div> 
			<div class="col-md-2 longonBorder" ><?php  sectionB_sevenrow_secondcolumn(); ?></div> 
			<div class="col-md-1 longonBorder partition" ></div> 
			<div class="col-md-4 longonBorder" ><?php  sectionB_paaman_row2_firstcolumn(); ?></div> 
		</div>
		  
		<!-- end --> 
	<!-- eight row -->
		<div class="col-lg-12 row">
			<div class="col-md-4 longonBorder " ><?php  sectionB_sixrow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-2 longonBorder " ><?php  sectionB_sixrow_secondcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-4 longonBorder " ><?php  sectionB_paaman_row3_firstcolumn(); ?></div> 
		</div>
		  
		<!-- end -->
		<!-- seven row -->
		<div class="col-lg-12 row"> 
			<div class="col-md-8 longonBorder partition" ></div> 
			<div class="col-md-4 longonBorder" ><?php  sectionB_paaman_row4_firstcolumn(); ?></div> 
		</div>
		  
		<!-- end --> 
		<!-- six row -->
		<div class="col-lg-12 row">
			<div class="col-md-2 longonBorder " ><?php  sectionB_fifthrow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-1 longonBorder " ><?php  sectionB_fifthrow_secondcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-2 longonBorder " ><?php  sectionB_fifthrow_thirdcolumn(); ?></div> 
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-4 longonBorder " ><?php  sectionB_paaman_row5_firstcolumn(); ?></div>
		</div>
		  
		<!-- end -->

		<!-- fifth row -->
		<div class="col-lg-12 row"> 
			<div class="col-md-8 longonBorder partition" ></div> 
			<div class="col-md-4 longonBorder" ><?php  sectionB_paaman_row6_firstcolumn(); ?></div> 
		</div>
		  
		<!-- end --> 
		<!-- forth row -->
		<div class="col-lg-12 row">
			<div class="col-md-2 longonBorder " ><?php  sectionB_forthrow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-2 longonBorder " ><?php  sectionB_forthrow_secondcolumn(); ?></div>
			<div class="col-md-2 longonBorder partition" ></div>
			<div class="col-md-5 longonBorder " ><?php  sectionB_forthrow_thirdcolumn(); ?></div>
		</div>
		  
		<!-- end -->
		<!-- third row -->
		<div class="col-lg-12 row">
			<div class="col-md-2 longonBorder " ><?php  sectionB_thirdrow_firstcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-2 longonBorder " ><?php  sectionB_thirdrow_secondcolumn(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-6 longonBorder " ><?php  sectionB_thirdrow_thirdcolumn(); ?></div>
		</div>
		  
		<!-- end -->
		 <!-- second row -->
		 <div class="col-lg-12 row">
		  <div class="col-md-10 longonBorder " ><?php  sectionB_secondrow_firstcolumn(); ?></div>
		  <div class="col-md-2 longonBorder "></div> 
		 </div>
		 <!-- end -->  
		  <!-- first row -->
		 <div class="col-lg-12 row">
			<div class="col-md-1 longonBorder partition"></div>
			<div class="col-md-2 longonBorder "><?php  sectionB_firstrow(); ?></div>
			<div class="col-md-1 longonBorder partition" ></div>
			<div class="col-md-6 longonBorder "  ><?php  sectionB_firstrow_secondcolumn(); ?></div>
			<div class="col-md-2 longonBorder "></div>
		 </div>
		  
		  <!-- end firs row -->
	</div>  

</div>  
	<div class="col-md-12 row"  > Highway</div>  
</div>
 
</div>




