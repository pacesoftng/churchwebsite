
<style type="text/css">
	#ab > td {
		background-color: #eee;
	}
</style>
<table>
	<tr>
		<td><div><?php retrieveData_ASC_Horizontal_A_odd_bgcolor(1,37,'gray');
	retrieveData_ASC_Horizontal_A_even_bgcolor(1,38,'gray'); ?></div></td>
	<td >
		<div style="margin-top: -30px;"> 
		<table>
			<tr id="ab">
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(1,3,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(4,6,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(7,9,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(10,12,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(13,15,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(16,18,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(19,21,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(22,24,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(25,27,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(28,30,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(31,33,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(34,36,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(37,39,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(40,42,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(43,45,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(46,48,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(49,51,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(52,54,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(55,57,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(58,60,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(61,63,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(64,66,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(67,69,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(70,72,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(73,75,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(76,78,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(79,81,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(82,84,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(85,87,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(88,90,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(91,93,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(94,96,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(97,99,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(100,102,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(103,105,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(106,108,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(109,111,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(112,114,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(115,117,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(118,120,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(121,123,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(124,126,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(127,129,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(130,132,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(133,135,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(136,138,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(139,141,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(142,144,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(145,147,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(148,150,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(151,153,'gray');?></div></td> 
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(154,156,'gray');?></div></td>
				<td><div style="margin-left: -4px;"><?php retrieveData_ASC_Vertical_B_bgcolor(157,159,'gray');?></div></td>
			</tr>
		</table>
		</div>
	</td>
	</tr>
</table>
 